# roomba_robot
This repository is for "SPC 428:Robotics and Mechatronics" Course project.

**Still under development.**
